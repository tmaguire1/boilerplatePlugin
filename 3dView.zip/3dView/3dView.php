<?php
/*
Plugin Name:  3D View
Plugin URI:   https://www.wpbeginner.com
Description:  A short little description of the plugin. It will be displayed on the Plugins page in WordPress admin area.
Version:      1.0
Author:       WPBeginner
Author URI:   https://www.wpbeginner.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wpb-tutorial
Domain Path:  /languages
*/



add_action('wp_enqueue_scripts','_3d_view_init');

function _3d_view_init() {
    wp_enqueue_script( '3d-view-js', plugins_url( '/script.js', __FILE__ ));
}


function _3dView($content) {


    $content .= '<h1 id="3dView">3D View</h1>';

    return $content;
    
}


    // Hook our function to WordPress the_content filter
    add_filter('the_content', '_3dView'); 